# LibraryRobotMDP

MATLAB/Octave code for *An MDP-Based Framework for Attention-Aware Navigation Behavior in Library Robots* (revised model, Phase B).
It replaces the earlier partial code (`floor25`, `Index2SMDP`, `S2IndexMDP`, `rewardMDP`, `StateTransitionMDP`, `xpNextGivenAction`).

Tested with GNU Octave 8.4. Written for MATLAB R2019b or later; no toolboxes are needed.

## Quick start

```matlab
cd LibraryRobotMDP
run_phaseB          % build + verify + solve, tune baselines, smoke-test, export
```

Outputs go to `results/`:
- `phaseB_log.txt`: console log, including software version, seed, solver iterations and policy shares
- `phaseB.mat`: the parameters, solved model, checks, tuned thresholds and Monte Carlo smoke test
- `model_export/*.csv`: the policy, transition matrices (sparse triplets per action), rewards, action table and parameter list, for the supplementary material

## Folder layout

| Folder | File | Purpose | Paper |
|---|---|---|---|
| `model/` | `params_default.m` | every parameter in one struct | Tables 2–5 |
| | `finalize_params.m` | derived quantities (action table, p(a), dimensions) and input checks | Eq. 2, 4 |
| | `state_index.m`, `state_from_index.m` | state ↔ index (`sub2ind`); terminal state = 271 | Sec. 2.1 |
| | `disturbance_level.m` | g(x_a,x_p): squared (paper) or linear (sensitivity) | Eq. 6 |
| | `cost_terms.m` | disruption, n_p, m_p, r_p, d_p, C | Eq. 6–12 |
| | `prox_distribution.m` | proximity transition with mobility perturbation | Table 4, Eq. 5 |
| | `build_transition_model.m` | full kernel P(s'\|s,a), sparse, one matrix per action | Eq. 3 |
| | `build_reward_model.m` | expected reward R(s,a) | Eq. 6 |
| `solver/` | `value_iteration.m` | V₀=0, stop when ‖ΔV‖∞ < ε(1−γ)/(2γ) | Eq. 13 |
| | `solve_mdp.m` | builds and solves the model from `P` | |
| | `check_model.m` | row sums, absorbing terminal state, index maps, simulator-vs-model agreement, Bellman residual | |
| `policies/` | `make_policy_mdp.m` | optimal policy | |
| | `make_policy_myopic.m` | same model with γ = 0, which isolates the effect of lookahead | |
| | `rule_based_action.m`, `rule_params_default.m`, `make_policy_rule.m` | fully specified rule-based baseline (rules R1–R4 plus optional hysteresis) | R2-6 |
| | `tune_rule_based.m` | grid search of the rule thresholds on separate episodes | R2-6 |
| | `make_policy_fixed.m` | Efficiency-only (always v_max + shortest) and Always-cautious (always v_st + detour) | |
| | `make_baselines.m` | all six policies in a fixed order | |
| `simulation/` | `sample_next_state.m` | samples s' from the **same** components as the model | |
| | `simulate_episode.m` | one policy × one scenario, scripted or Markov exogenous variables, optional task restart | |
| | `define_scenarios.m` | the four trajectory scenarios | R1-2 |
| | `run_scenario.m` | all policies on one scenario with common random numbers | |
| | `run_monte_carlo.m` | Monte Carlo evaluation, mean / SD / 95% CI | |
| | `compute_metrics.m` | evaluation metrics | task 10 |
| | `plot_trajectories.m` | 4-panel trajectory figure, 300-dpi PNG | |
| `utils/` | `env_info.m`, `policy_summary.m`, `export_model.m`, `print_metrics_table.m` | reproducibility, state-space analysis, export, tables | R2-8 |

## Conventions

- State `s = [xa xm xp xc xtd]` uses the paper's values (0-based levels, `xtd ∈ 1..n`). `xtd = 0` means the terminal state. `x_t` is implicit: it equals 1 in every non-terminal state.
- Actions: `1 vmax-shortest, 2 vmax-widen, 3 vmax-detour, 4 vst-shortest, 5 vst-widen, 6 vst-detour, 7 hold`.
- Every policy uses the same interface: `[a, mem] = pol.act(s, mem)`, starting from `mem = pol.init`.
- Ties in the argmax go to the lowest action index, so the solution is deterministic.
- `P.seed = 2026` is the master seed. Rule tuning uses `seed + 1000`, scenario k uses `seed + k`, and the Monte Carlo runs use `seed`.

## Metrics (`compute_metrics.m`)

| Metric | Meaning |
|---|---|
| discounted and undiscounted return | |
| tasks completed, completion time | |
| intrusions | epochs in the intimate zone with a focused patron |
| severe intrusions | epochs in the intimate zone with a deeply focused patron |
| disturbance exposure | Σg |
| noise exposure | Σg·n_l |
| action switches | counted within a task |
| proximity reversals | counted within a task; this is the oscillation measure |
| mean speed, mean extra path | |

## Phase C

```matlab
cd LibraryRobotMDP
run_phaseC          % tasks 11-14; needs results/phaseB.mat (otherwise re-tunes the rule baseline)
```

Settings are at the top of `run_phaseC.m`: `cfg.nMC` (Monte Carlo episodes, default 1000), `cfg.nMCsens` (episodes per sensitivity variant) and `cfg.trajPolicies` (policies drawn in the trajectory figures).
Outputs go to `results/phaseC/`:

| Task | Files |
|---|---|
| 11 policy across the state space | `policy_shares.csv`, `fig_policy_shares.png` |
| 12 four scenarios | `scenarios.csv` (scenario table), `scenario_metrics_S1..S4.csv`, `fig_traj_S1..S4.png` |
| 13 Monte Carlo | `mc_summary.csv` (mean and 95% CI), `mc_paired_tests.csv` (MDP minus each baseline: paired t-test, p-value, effect size) |
| 13 sensitivity | `sensitivity.csv` (weights ×0.5/×1.5, linear levels, γ = 0.8/0.95/0.99), `sensitivity_sweep.csv`, `fig_sensitivity_wd.png` |
| 14 exam-season environment | `exam_mc_summary.csv`, `exam_policy_change.txt`, `fig_traj_exam.png` |
| all | `phaseC_key_numbers.txt` (numbers for the text), `phaseC_log.txt`, `phaseC.mat` |

New Phase C functions:
- `solver/sensitivity_analysis.m`
- `model/env_exam_season.m` (the exam-season matrices are assumptions; state them in the paper)
- `utils/paired_test.m` (no toolbox needed)
- `utils/write_csv.m`, `utils/plot_policy_summary.m`, `utils/plot_sensitivity_sweep.m`, `utils/describe_script.m`

Before running, check that `define_scenarios.m` and `env_exam_season.m` describe what you want to report.

## Paper figures

After `run_phaseC`, regenerate Figures 1–10 of the paper at print size (300 dpi, 9–10 pt text):

```
python figures/make_paper_figures.py results/phaseC figures/out
```

This needs Python 3 with numpy, scipy and matplotlib. Figures 1–4 are diagrams. Figures 5–10 are drawn from `policy_shares.csv`, `traj_S<k>_p<j>.csv` (written by `run_phaseC.m` through `utils/export_trajectory_csv.m`) and `sensitivity_sweep.csv`.
