"""Paper figures 1-10, drawn at final print size (6.3 in text width), 9-10 pt text, 300 dpi.
Requires Python 3 with numpy, scipy and matplotlib. Reads the CSV outputs of run_phaseC.m."""
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Ellipse, Circle, Rectangle, Polygon, FancyArrowPatch

import os, sys
# usage: python make_paper_figures.py [results/phaseC folder] [output folder]
R = (sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), '..', 'results', 'phaseC')).rstrip('/') + '/'
OUT = (sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(__file__), 'out')).rstrip('/') + '/'
S = R.rstrip('/')     # trajectory CSVs (traj_S<k>_p<j>.csv) are written by run_phaseC.m into results/phaseC
os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({'font.family': 'Liberation Sans', 'font.size': 10, 'mathtext.fontset': 'dejavusans',
                     'axes.linewidth': 0.8, 'savefig.dpi': 300})
BLUE, RED, YEL, PUR, GREY = '#0072BD', '#D95319', '#EDB120', '#7E2F8E', '#7f7f7f'
W = 6.3


def box(ax, x, y, w, h, text, fc='white', ec='black', fs=10, round_=True, lw=1.0):
    p = FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle='round,pad=0.02,rounding_size=0.08' if round_ else 'square,pad=0.0',
                       fc=fc, ec=ec, lw=lw)
    ax.add_patch(p)
    ax.text(x, y, text, ha='center', va='center', fontsize=fs, wrap=True)


def arrow(ax, p, q, cs='arc3', lw=1.0, ls='-', color='black'):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle='-|>', mutation_scale=11, lw=lw, color=color,
                                 connectionstyle=cs, linestyle=ls, shrinkA=0, shrinkB=0))


# ---------------- Figure 1: scenario schematic (top view) ----------------
def fig1():
    fig, ax = plt.subplots(figsize=(W, 3.35))
    ax.set_xlim(-0.2, 12.2); ax.set_ylim(-0.35, 6.75); ax.set_aspect('equal'); ax.axis('off')
    shelf = dict(fc='#d9c7a7', ec='#8c6d46', lw=0.8)
    ax.add_patch(Rectangle((0, -0.2), 12, 0.5, **shelf))                  # bottom shelf
    ax.add_patch(Rectangle((0, 3.3), 2.0, 0.5, **shelf))                   # middle shelf with two gaps
    ax.add_patch(Rectangle((3.0, 3.3), 6.0, 0.5, **shelf))
    ax.add_patch(Rectangle((10.0, 3.3), 2.0, 0.5, **shelf))
    ax.add_patch(Rectangle((0, 5.65), 12, 0.5, **shelf))                   # top shelf
    ax.text(6.0, 4.0 - 0.45, 'bookshelves', ha='center', va='center', fontsize=8, color='#5a4630')
    ax.text(11.9, 2.95, 'main aisle', ha='right', va='center', fontsize=8, color=GREY, rotation=0)
    ax.text(11.9, 4.75, 'adjacent aisle', ha='right', va='center', fontsize=8, color=GREY)
    # patron with proxemic zones
    px, py = 6.0, 1.15
    ax.add_patch(Circle((px, py), 1.2, fc='#fde9c8', ec=YEL, lw=1.0, zorder=1))
    ax.add_patch(Circle((px, py), 0.45, fc='#f7c6b5', ec=RED, lw=1.0, zorder=2))
    ax.add_patch(Rectangle((px - 0.55, py - 0.75), 1.1, 0.32, fc='#bfa27a', ec='#8c6d46', lw=0.6, zorder=3))  # desk
    ax.add_patch(Circle((px, py), 0.17, fc='#444444', ec='none', zorder=4))
    ax.text(px - 1.35, py - 0.25, 'focused patron\n(reading)', ha='right', va='center', fontsize=8)
    ax.annotate('intimate: $d<0.45$ m', xy=(px + 0.3, py - 0.3), xytext=(px + 1.55, py - 0.85), fontsize=8, ha='left', va='center',
                arrowprops=dict(arrowstyle='-', lw=0.6))
    ax.annotate('near: $0.45\\leq d\\leq1.2$ m', xy=(px + 1.12, py - 0.42), xytext=(px + 1.55, py - 0.35), fontsize=8, ha='left', va='center',
                arrowprops=dict(arrowstyle='-', lw=0.6))
    ax.text(px + 1.55, py + 0.12, 'far: $d>1.2$ m', fontsize=8, ha='left', va='center')
    # other patrons (crowd density)
    for (cx, cy) in [(1.45, 2.8), (3.3, 2.75), (8.0, 4.25)]:
        ax.add_patch(Circle((cx, cy), 0.15, fc=GREY, ec='none', zorder=4))
    ax.text(3.3, 2.45, 'other patrons', ha='center', va='top', fontsize=7, color=GREY)
    # robot and goal
    rx, ry = 0.75, 1.55
    ax.add_patch(FancyBboxPatch((rx - 0.32, ry - 0.32), 0.64, 0.64, boxstyle='round,pad=0.0,rounding_size=0.12',
                                fc='#dce9f5', ec=BLUE, lw=1.2, zorder=5))
    ax.text(rx, ry, 'R', ha='center', va='center', fontsize=9, fontweight='bold', color=BLUE, zorder=6)
    ax.text(rx, ry - 0.5, 'robot', ha='center', va='top', fontsize=8)
    gx, gy = 11.3, 1.55
    ax.plot(gx, gy, marker='*', ms=13, color='black', zorder=5)
    ax.text(gx, gy - 0.35, 'goal', ha='center', va='top', fontsize=8)
    # routes
    x = np.linspace(rx + 0.35, gx - 0.25, 200)
    ax.plot(x, np.full_like(x, ry), color=BLUE, lw=1.8, zorder=4)
    ax.text(3.0, ry - 0.12, r'$\rho_{\mathrm{sh}}$ shortest', color=BLUE, fontsize=9, va='top', ha='center')
    xw = np.linspace(rx + 0.35, gx - 0.25, 300)
    yw = ry + (2.6 - ry) * np.exp(-((xw - px) / 1.9) ** 4)
    ax.plot(xw, yw, color=RED, lw=1.8, ls='--', zorder=4)
    ax.text(px, 2.68, r'$\rho_{\mathrm{wd}}$ widened arc', color=RED, fontsize=9, va='bottom', ha='center')
    xd = [rx + 0.35, 2.0, 2.5, 3.0, 9.0, 9.5, 10.0, gx - 0.25]
    yd = [ry, ry + 0.4, 3.55, 4.75, 4.75, 3.55, ry + 0.4, ry]
    from scipy.interpolate import make_interp_spline
    t = np.linspace(0, 1, len(xd)); tt = np.linspace(0, 1, 300)
    sx = make_interp_spline(t, xd, k=2)(tt); sy = make_interp_spline(t, yd, k=2)(tt)
    ax.plot(sx, sy, color=PUR, lw=1.8, ls=':', zorder=4)
    ax.text(6.0, 4.95, r'$\rho_{\mathrm{dt}}$ detour', color=PUR, fontsize=9, va='bottom', ha='center')
    ax.text(0.0, 6.3, r'velocity: $v_{\max}=0.8$ m/s, $v_{\mathrm{st}}=0.4$ m/s or stop ($a_{\mathrm{hold}}$)',
            fontsize=8, ha='left', va='bottom')
    fig.subplots_adjust(0.005, 0.005, 0.995, 0.995)
    fig.savefig(OUT + 'fig1_scenario.png'); plt.close(fig)


# ---------------- Figure 2: MDP framework ----------------
def fig2():
    fig, ax = plt.subplots(figsize=(W, 3.0))
    ax.set_xlim(0, 10); ax.set_ylim(0, 4.8); ax.axis('off')
    items = [r'State space $\mathcal{S}$ (Section 2.1)', r'Action space $\mathcal{A}$ (Section 2.2)',
             r"Transition model $P(s'\,|\,s,a)$ (Section 2.3)", r"Reward $r(s,a,s')$ (Section 2.4)",
             r'Discount factor $\gamma$ (Section 2.5)']
    ys = [4.25, 3.35, 2.45, 1.55, 0.65]
    for y, t in zip(ys, items):
        box(ax, 2.05, y, 3.9, 0.66, t, fs=9)
        ax.plot([4.0, 4.45], [y, y], color='black', lw=1.0)
    ax.plot([4.45, 4.45], [ys[-1], ys[0]], color='black', lw=1.0)
    arrow(ax, (4.45, 3.95), (5.1, 3.95))
    box(ax, 7.4, 3.95, 4.6, 0.9, 'Value iteration\n' + r"$V_{k+1}(s)=\max_a\,[R(s,a)+\gamma\sum_{s'}P(s'|s,a)\,V_k(s')]$", fs=8)
    arrow(ax, (7.35, 3.5), (7.35, 2.85))
    dia = Polygon([[7.35, 2.85], [9.0, 2.2], [7.35, 1.55], [5.7, 2.2]], closed=True, fc='white', ec='black', lw=1.0)
    ax.add_patch(dia)
    ax.text(7.35, 2.2, r'$\|V_{k+1}-V_k\|_\infty<$ tol?', ha='center', va='center', fontsize=8.5)
    ax.plot([9.0, 9.85, 9.85], [2.2, 2.2, 3.95], color='black', lw=1.0)
    arrow(ax, (9.85, 3.95), (9.7, 3.95))
    ax.text(9.25, 2.32, 'No', fontsize=9, va='center')
    arrow(ax, (7.35, 1.55), (7.35, 0.95))
    ax.text(7.45, 1.25, 'Yes', fontsize=9, va='center')
    box(ax, 7.35, 0.6, 4.2, 0.66, r"Optimal policy $\pi^*(s)=\arg\max_a Q(s,a)$", fs=9)
    fig.subplots_adjust(0.005, 0.005, 0.995, 0.995)
    fig.savefig(OUT + 'fig2_framework.png'); plt.close(fig)


# ---------------- Figure 3: state variables ----------------
def fig3():
    fig, ax = plt.subplots(figsize=(W, 2.7))
    ax.set_xlim(0, 10); ax.set_ylim(0, 4.3); ax.axis('off')
    vars_ = [(r'$x_a$', 'attention', r'$\{0,1,2\}$'), (r'$x_m$', 'mobility', r'$\{0,1\}$'),
             (r'$x_p$', 'proximity', r'$\{0,1,2\}$'), (r'$x_c$', 'crowd density', r'$\{0,1,2\}$'),
             (r'$x_t$', 'active task', r'$\{0,1\}$'), (r'$x_{td}$', 'remaining\nduration', r'$\{0,\ldots,5\}$')]
    xs = np.linspace(0.85, 9.15, 6)
    for x, (sym, name, dom) in zip(xs, vars_):
        ax.add_patch(Ellipse((x, 3.3), 1.55, 1.45, fc='#eef4fa', ec=BLUE, lw=1.0))
        ax.text(x, 3.72, sym, ha='center', va='center', fontsize=12)
        ax.text(x, 3.25, name, ha='center', va='center', fontsize=7.5 if '\n' in name else 8, linespacing=0.95)
        ax.text(x, 2.8, dom, ha='center', va='center', fontsize=8)
        arrow(ax, (x, 2.62), (5.0 + (x - 5.0) * 0.32, 1.45))
    ax.add_patch(Ellipse((5.0, 0.95), 4.6, 1.05, fc='white', ec='black', lw=1.2))
    ax.text(5.0, 1.12, r'State $s=(x_a,x_m,x_p,x_c,x_t,x_{td})$', ha='center', va='center', fontsize=10)
    ax.text(5.0, 0.72, r'270 non-terminal states + terminal state $s_T$', ha='center', va='center', fontsize=8)
    fig.subplots_adjust(0.005, 0.005, 0.995, 0.995)
    fig.savefig(OUT + 'fig3_state.png'); plt.close(fig)


# ---------------- Figure 4: simulation loop ----------------
def fig4():
    fig, ax = plt.subplots(figsize=(W, 2.35))
    ax.set_xlim(0, 10); ax.set_ylim(0, 3.7); ax.axis('off')
    y = 2.6
    steps = ['Initialize state\n$s_0$ (Table 7)', 'Apply scripted\nexogenous values', 'Select action\n$a=\\pi(s)$',
             'Sample next state\n$s\'\\sim P(\\cdot|s,a)$', 'Record state,\naction and costs']
    xs = [0.95, 2.95, 4.95, 6.95, 8.95]
    for i, (x, t) in enumerate(zip(xs, steps)):
        box(ax, x, y, 1.75, 0.95, t, fs=8.5, fc='#eef4fa' if i == 0 else 'white')
        if i < 4:
            arrow(ax, (x + 0.875, y), (xs[i + 1] - 0.875, y))
    # loop back
    ax.plot([8.95, 8.95, 2.95], [y - 0.475, 1.35, 1.35], color='black', lw=1.0)
    arrow(ax, (2.95, 1.35), (2.95, y - 0.475))
    ax.text(5.95, 1.42, 'next epoch (new task with $x_{td}=5$ if the task was completed)', ha='center', va='bottom', fontsize=8)
    arrow(ax, (8.95, 1.35), (8.95, 0.85))
    ax.text(8.85, 1.1, 'after 50 epochs', fontsize=8, va='center', ha='right')
    box(ax, 8.6, 0.45, 2.6, 0.7, 'Trajectory and metrics\n(Tables 8, 9)', fs=8.5, fc='#eef4fa')
    fig.subplots_adjust(0.005, 0.005, 0.995, 0.995)
    fig.savefig(OUT + 'fig4_simloop.png'); plt.close(fig)


# ---------------- Figure 5: policy shares ----------------
def fig5():
    rows = {r['group']: r for r in csv.DictReader(open(R + 'policy_shares.csv'))}
    keys = ['vmax-shortest', 'vmax-widen', 'vmax-detour', 'vst-detour']
    labels = [r'$(v_{\max},\rho_{\mathrm{sh}})$', r'$(v_{\max},\rho_{\mathrm{wd}})$', r'$(v_{\max},\rho_{\mathrm{dt}})$',
              r'$(v_{\mathrm{st}},\rho_{\mathrm{dt}})$']
    cols = [BLUE, RED, YEL, PUR]
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.9), sharey=True)
    for ax, grp, xl, ttl in [(axs[0], ['xa=0', 'xa=1', 'xa=2'], ['distracted', 'moderately\nfocused', 'deeply\nfocused'], r'Attention $x_a$'),
                              (axs[1], ['xp=0', 'xp=1', 'xp=2'], ['far', 'near', 'intimate'], r'Proximity $x_p$')]:
        bottom = np.zeros(3)
        for k, lab, c in zip(keys, labels, cols):
            v = np.array([float(rows[g][k]) for g in grp])
            ax.bar(range(3), v, 0.6, bottom=bottom, color=c, edgecolor='black', lw=0.5, label=lab)
            bottom += v
        ax.set_xticks(range(3)); ax.set_xticklabels(xl); ax.set_xlabel(ttl); ax.set_ylim(0, 100)
    axs[0].set_ylabel('Share of states (%)')
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc='upper center', ncol=4, frameon=False, fontsize=9, bbox_to_anchor=(0.5, 1.0))
    fig.subplots_adjust(left=0.1, right=0.99, bottom=0.2, top=0.88, wspace=0.08)
    fig.savefig(OUT + 'fig5_policy_shares.png'); plt.close(fig)


# ---------------- Figures 6-9: trajectories ----------------
def traj(k):
    D = [np.loadtxt(f'{S}/traj_S{k}_p{j}.csv', delimiter=',') for j in (1, 3, 4)]
    names = ['MDP', 'Rule-based (reactive)', 'Rule-based (tuned)']
    styles = [dict(color=BLUE, lw=2.0, ls='-'), dict(color=RED, lw=1.5, ls='--'), dict(color=YEL, lw=1.7, ls=':')]
    fig, axs = plt.subplots(4, 1, figsize=(W, 5.6), sharex=True)
    ylab = [r'Attention $x_a$', r'Proximity $x_p$', r'Velocity $v$', r'Routing $\rho$']
    yt = [(range(3), ['distracted', 'moderate', 'deep']), (range(3), ['far', 'near', 'intimate']),
          ((1, 2, 3), [r'$v_{\max}$', r'$v_{\mathrm{st}}$', r'$v_0$']), ((1, 2, 3), ['shortest', 'widened', 'detour'])]
    yl = [(-0.35, 2.35), (-0.35, 2.35), (0.65, 3.35), (0.65, 3.35)]
    for p, ax in enumerate(axs):
        for j, d in enumerate(D):
            x, y = d[:, 0], d[:, p + 1]
            ax.step(np.r_[x, x[-1] + 1], np.r_[y, y[-1]], where='post', label=names[j], **(styles[0] if p == 0 else styles[j]))
            if p == 0:
                break
        ax.set_yticks(list(yt[p][0])); ax.set_yticklabels(yt[p][1]); ax.set_ylim(*yl[p]); ax.set_xlim(1, 51)
        ax.set_ylabel(ylab[p]); ax.grid(axis='y', color='#e5e5e5', lw=0.6); ax.set_axisbelow(True)
    axs[-1].set_xlabel('Decision epoch')
    h, l = axs[1].get_legend_handles_labels()
    fig.legend(h, l, loc='upper center', ncol=3, frameon=False, fontsize=9, bbox_to_anchor=(0.55, 1.0))
    fig.align_ylabels(axs)
    fig.subplots_adjust(left=0.19, right=0.985, bottom=0.08, top=0.945, hspace=0.18)
    fig.savefig(OUT + f'fig{5 + k}_traj_S{k}.png'); plt.close(fig)


# ---------------- Figure 10: sensitivity sweep ----------------
def fig10():
    d = np.loadtxt(R + 'sensitivity_sweep.csv', delimiter=',', skiprows=1)
    fig, ax = plt.subplots(figsize=(4.8, 2.8))
    ax.plot(d[:, 0], d[:, 1], '-o', color=BLUE, lw=1.6, ms=4, label='stealth velocity optimal')
    ax.plot(d[:, 0], d[:, 2], '--s', color=RED, lw=1.6, ms=4, label='detour optimal')
    ax.axvline(30, color='black', ls=':', lw=1.2, label=r'nominal $w_d=30$')
    ax.set_xlim(0, 60); ax.set_ylim(0, 100); ax.set_xlabel(r'Delay weight $w_d$'); ax.set_ylabel('Share of states (%)')
    ax.grid(color='#e5e5e5', lw=0.6); ax.set_axisbelow(True)
    ax.legend(frameon=False, fontsize=9, loc='upper right')
    fig.tight_layout(pad=0.3)
    fig.savefig(OUT + 'fig10_sensitivity.png'); plt.close(fig)


fig1(); fig2(); fig3(); fig4(); fig5()
for k in range(1, 5):
    traj(k)
fig10()
print('done')
