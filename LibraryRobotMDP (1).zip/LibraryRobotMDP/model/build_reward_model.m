function R = build_reward_model(T, P)
%BUILD_REWARD_MODEL  Expected one-step reward R(s,a) = E_{s'}[ r(s,a,s') ], Eq. (6).
%   R is nS-by-nA:
%     R(s,a) = -w_D*g(xa,xp) - C(s,a) + w_T * P(s' = s_T | s, a)
%   The terminal state yields zero reward for every action.
R = zeros(P.nS, P.nA);
for a = 1:P.nA
    pDone = full(T{a}(:, P.sT));
    for i = 1:P.nActive
        s = state_from_index(i, P);
        c = cost_terms(s, a, P);
        R(i, a) = -c.disruption - c.C + P.w.T * pDone(i);
    end
end
R(P.sT, :) = 0;
end
