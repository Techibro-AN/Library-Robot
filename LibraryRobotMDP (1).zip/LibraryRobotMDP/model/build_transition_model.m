function T = build_transition_model(P)
%BUILD_TRANSITION_MODEL  Full kernel P(s'|s,a) of Eq. (3).
%   T is a 1-by-nA cell array; T{a} is a sparse nS-by-nS row-stochastic
%   matrix with T{a}(i,j) = P(s_j | s_i, a). Successors with xtd' = 0 are
%   mapped to the absorbing terminal state P.sT.
nS = P.nS;  nA = P.nA;
T = cell(1, nA);
for a = 1:nA
    pProg = P.act.p(a);
    rows = []; cols = []; vals = [];
    for i = 1:P.nActive
        s = state_from_index(i, P);
        xa = s(1); xm = s(2); xp = s(3); xc = s(4); xtd = s(5);
        dP = prox_distribution(xp, xm, xc, a, P);
        % remaining duration: decrement with probability p(a)  (Eq. 4)
        tdNext = [xtd - 1, xtd];  tdProb = [pProg, 1 - pProg];
        for ka = 0:2
          for km = 0:1
            for kc = 0:2
              pe = P.Pa(xa+1, ka+1) * P.Pm(xm+1, km+1) * P.Pc(xc+1, kc+1);
              if pe == 0, continue; end
              for kp = 0:2
                if dP(kp+1) == 0, continue; end
                for k = 1:2
                  if tdProb(k) == 0, continue; end
                  j = state_index([ka km kp kc tdNext(k)], P);
                  rows(end+1) = i; cols(end+1) = j;         %#ok<AGROW>
                  vals(end+1) = pe * dP(kp+1) * tdProb(k);  %#ok<AGROW>
                end
              end
            end
          end
        end
    end
    rows(end+1) = P.sT; cols(end+1) = P.sT; vals(end+1) = 1;   % absorbing
    T{a} = sparse(rows, cols, vals, nS, nS);                    % duplicates are summed
end
end
