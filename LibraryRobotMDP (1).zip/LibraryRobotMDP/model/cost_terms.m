function c = cost_terms(s, a, P)
%COST_TERMS  State disruption term and action-dependent costs, Eqs. (6)-(12).
%   s = [xa xm xp xc xtd] (non-terminal), a = action index (1..7).
%   Returns struct with fields
%     disruption  w_D * g(xa,xp)                       (state term in Eq. 6)
%     np, mp, rp, dp, C                                (Eqs. 7, 9, 10, 11, 12)
xa = s(1); xm = s(2); xp = s(3);
xt = double(s(5) >= 1);
g  = disturbance_level(xa, xp, P);
c.disruption = P.w.D * g;
c.np = P.w.n * g * P.act.nl(a);              % Eq. 7-8
c.mp = P.w.m * xm * g;                       % Eq. 9
c.rp = P.w.r * P.act.dl(a);                  % Eq. 10
c.dp = P.w.d * xt * (1 - P.act.vr(a));       % Eq. 11
c.C  = c.np + c.mp + c.rp + c.dp;            % Eq. 12
end
