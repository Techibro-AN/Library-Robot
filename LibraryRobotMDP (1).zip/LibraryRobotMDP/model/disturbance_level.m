function g = disturbance_level(xa, xp, P)
%DISTURBANCE_LEVEL  Attention-proximity factor used by the disruption, noise and
%   mobility terms: xa^2*xp^2 (paper, 'squared') or xa*xp ('linear', sensitivity).
switch lower(P.disturbanceForm)
    case 'squared', g = (xa.^2) .* (xp.^2);
    case 'linear',  g = xa .* xp;
    otherwise, error('Unknown disturbanceForm "%s".', P.disturbanceForm);
end
end
