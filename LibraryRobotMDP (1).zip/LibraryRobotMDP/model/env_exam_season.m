function Pe = env_exam_season(P)
%ENV_EXAM_SEASON  Parameters of the second library environment (exam season).
%   Patrons are more often, and more persistently, deeply focused, and the
%   library is more crowded. Only the environment (exogenous transitions)
%   changes; the reward weights are kept, so any change in behavior comes
%   from re-solving the MDP for the new environment.
%   >> These matrices are modelling assumptions: state them in the paper. <<
Pe = P;
Pe.Pa = [0.70 0.20 0.10;
         0.05 0.75 0.20;
         0.02 0.08 0.90];     % attention drifts towards, and stays at, deep focus
Pe.Pc = [0.60 0.30 0.10;
         0.05 0.75 0.20;
         0.02 0.13 0.85];     % crowding is more frequent and persistent
Pe = finalize_params(Pe);
end
