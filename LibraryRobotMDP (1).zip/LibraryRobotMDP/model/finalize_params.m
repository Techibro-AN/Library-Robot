function P = finalize_params(P)
%FINALIZE_PARAMS  Recompute all quantities derived from the base parameters.
%   Call after changing any field of P (done automatically by solve_mdp).

% ---- state-space dimensions ----
P.dims = [3 2 3 3 P.n];              % [xa xm xp xc xtd]
P.nActive = prod(P.dims);            % 270 non-terminal states
P.nS = P.nActive + 1;                % + absorbing terminal state
P.sT = P.nS;                         % index of the terminal state

% ---- action table (Eq. 2): velocity index (1 vmax, 2 vst, 3 v0), routing (1 sh, 2 wd, 3 dt, 0 none)
A.vel  = [1 1 1 2 2 2 3];
A.rho  = [1 2 3 1 2 3 0];
A.name = {'vmax-shortest','vmax-widen','vmax-detour', ...
          'vst-shortest','vst-widen','vst-detour','hold'};
vRatioOfVel = [1, P.vst / P.vmax, 0];
A.vr = vRatioOfVel(A.vel);                               % v / vmax
A.dl = zeros(1, 7);  A.dl(A.rho > 0) = P.dl(A.rho(A.rho > 0));
A.nl = P.noiseLevel(A.vel);
A.p  = A.vr ./ (1 + A.dl);                               % Eq. 4: segment-completion prob.
A.speed = [P.vmax P.vst 0];  A.speed = A.speed(A.vel);   % m/s
P.act = A;
P.nA  = numel(A.vel);

% ---- sanity checks on probability inputs ----
chk = @(M) all(abs(sum(M, 2) - 1) < 1e-12) && all(M(:) >= 0);
assert(chk(P.Pa) && chk(P.Pm) && chk(P.Pc), 'Exogenous transition matrices must be row-stochastic.');
assert(all(P.sigmaW >= 0 & P.sigmaW <= 1) && all(P.sigmaD >= 0 & P.sigmaD <= 1), 'Success probabilities must lie in [0,1].');
assert(P.mu >= 0 && P.mu <= 0.5, 'mu must lie in [0, 0.5].');
assert(P.qScale >= 0 && P.qScale <= 1, 'qScale must lie in [0,1].');
assert(P.gamma >= 0 && P.gamma < 1, 'gamma must lie in [0,1).');
end
