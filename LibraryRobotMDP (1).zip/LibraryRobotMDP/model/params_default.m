function P = params_default()
%PARAMS_DEFAULT  All model, solver and simulation parameters (paper Tables 2-5).
%
%   P = params_default() returns the nominal parameter set used in the
%   paper. Every other function reads its parameters from this struct, so a
%   sensitivity analysis only needs to modify P and call finalize_params(P)
%   (or solve_mdp(P), which calls it).
%
%   State variables use the paper's values (0-based), not MATLAB indices:
%     xa  attention   {0 distracted, 1 moderately focused, 2 deeply focused}
%     xm  mobility    {0 stationary, 1 mobile}
%     xp  proximity   {0 far, 1 near, 2 intimate}
%     xc  crowd       {0 isolated, 1 moderate, 2 crowded}
%     xtd remaining task duration (path segments) {1..n}; xtd = 0 is the
%         absorbing terminal state s_T (task completed, x_t = 0).

% ---------------- State space ----------------
P.n = 5;                       % maximum remaining task duration (segments)

% ---------------- Physical realization (Table 2) ----------------
P.dt   = 2;                    % decision epoch [s]
P.vmax = 0.8;                  % standard velocity [m/s]
P.vst  = 0.4;                  % stealth velocity [m/s]
P.dl   = [0 0.2 0.5];          % extra path length for rho = shortest, widen, detour
P.noiseLevel = [1 0.3 0];      % n_l(v) for v = vmax, vst, v0

% ---------------- Exogenous transitions (Table 3) ----------------
% Rows: current value (0,1,2...), columns: next value.
P.Pa = [0.80 0.15 0.05;
        0.10 0.80 0.10;
        0.05 0.15 0.80];       % attention
P.Pm = [0.90 0.10;
        0.20 0.80];            % mobility
P.Pc = [0.80 0.15 0.05;
        0.10 0.80 0.10;
        0.05 0.15 0.80];       % crowd density

% ---------------- Proximity transition (Table 4, Eq. 5) ----------------
P.qScale = 0.9;                % approach probability q(v) = qScale * v/vmax
P.sigmaW = [0.95 0.75 0.40];   % widening success prob. for xc = 0,1,2
P.sigmaD = [0.95 0.90 0.80];   % detour success prob. for xc = 0,1,2
P.mu     = 0.1;                % mobile-patron perturbation (each direction)

% ---------------- Reward weights (Table 5) ----------------
P.w.T = 50;                    % completion reward
P.w.D = 5;                     % disruption
P.w.n = 5;                     % noise
P.w.m = 5;                     % mobility
P.w.r = 10;                    % route  (r_p = 0, 2, 5)
P.w.d = 30;                    % delay  (d_p = 0, 15, 30)
P.disturbanceForm = 'squared'; % 'squared' -> xa^2*xp^2 (paper), 'linear' -> xa*xp

% ---------------- Solver ----------------
P.gamma       = 0.9;
P.vi.epsilon  = 1e-6;          % epsilon-optimality target
P.vi.maxIter  = 100000;

% ---------------- Simulation ----------------
P.sim.nEpochs = 50;            % length of a scripted trajectory
P.sim.maxEpochsMC = 50;        % cap for Monte Carlo episodes
P.seed = 2026;                 % master random seed

P = finalize_params(P);
end
