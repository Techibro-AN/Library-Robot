function d = prox_distribution(xp, xm, xc, a, P)
%PROX_DISTRIBUTION  P_p(xp' | xp, xm, xc, a) of Eq. (5) as a 1x3 vector over xp' = 0,1,2.
%   Step 1: nominal outcome x~p from the routing choice (Table 4).
%   Step 2: mobility perturbation M_xm (identity if stationary; +/-1 zone
%           with probability mu each, clipped, if mobile).
nom = zeros(1, 3);
vel = P.act.vel(a);  rho = P.act.rho(a);
if vel == 3                                   % a_hold: zone unchanged
    nom(xp+1) = 1;
else
    q = P.qScale * P.act.vr(a);               % approach probability q(v)
    approach = zeros(1, 3);
    approach(min(xp+1, 2)+1) = approach(min(xp+1, 2)+1) + q;
    approach(xp+1) = approach(xp+1) + (1 - q);
    switch rho
        case 1                                % shortest path
            nom = approach;
        case 2                                % widened arc
            sw = P.sigmaW(xc+1);
            nom(max(xp-1, 0)+1) = nom(max(xp-1, 0)+1) + sw;
            nom = nom + (1 - sw) * approach;  % failure: forced onto shortest path
        case 3                                % detour
            sd = P.sigmaD(xc+1);
            nom(1) = nom(1) + sd;
            nom(xp+1) = nom(xp+1) + (1 - sd);
    end
end
d = nom * mobility_matrix(xm, P);
end

function M = mobility_matrix(xm, P)
if xm == 0
    M = eye(3);
else
    mu = P.mu;
    M = zeros(3);
    for k = 0:2
        M(k+1, k+1)          = M(k+1, k+1) + 1 - 2*mu;
        M(k+1, min(k+1,2)+1) = M(k+1, min(k+1,2)+1) + mu;
        M(k+1, max(k-1,0)+1) = M(k+1, max(k-1,0)+1) + mu;
    end
end
end
