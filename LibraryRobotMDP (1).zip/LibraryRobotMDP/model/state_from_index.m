function s = state_from_index(i, P)
%STATE_FROM_INDEX  Inverse of state_index. Returns [xa xm xp xc xtd] (paper values).
%   The terminal state P.sT is returned as [NaN NaN NaN NaN 0].
i = i(:);
s = nan(numel(i), 5);
term = i == P.sT;
s(term, 5) = 0;
a = ~term;
if any(a)
    [ia, im, ip, ic, itd] = ind2sub(P.dims, i(a));
    s(a, :) = [ia-1, im-1, ip-1, ic-1, itd];
end
end
