function i = state_index(s, P)
%STATE_INDEX  Map a state vector s = [xa xm xp xc xtd] (paper values) to its index.
%   xtd = 0 (task completed) maps to the terminal state P.sT.
%   s may be a k-by-5 matrix; i is then k-by-1.
if size(s, 2) ~= 5, s = reshape(s, [], 5); end
i = zeros(size(s, 1), 1);
term = s(:, 5) == 0;
i(term) = P.sT;
a = ~term;
if any(a)
    i(a) = sub2ind(P.dims, s(a,1)+1, s(a,2)+1, s(a,3)+1, s(a,4)+1, s(a,5));
end
end
