function [policies, extra] = make_baselines(model, thTuned)
%MAKE_BASELINES  The MDP policy and all comparison policies, in a fixed order:
%   1 MDP                 optimal policy (gamma = P.gamma)
%   2 Myopic              same model and reward, gamma = 0 (no lookahead)
%   3 Rule-based          purely reactive rules of the original paper
%   4 Rule-based (tuned)  thresholds from tune_rule_based, with hysteresis
%   5 Efficiency-only     always (vmax, shortest): conventional navigation
%   6 Always-cautious     always (vst, detour)
P = model.P;
[myopic, extra.myopicModel] = make_policy_myopic(P);
policies = { make_policy_mdp(model, 'MDP'), ...
             myopic, ...
             make_policy_rule(rule_params_default(), 'Rule-based (reactive)'), ...
             make_policy_rule(thTuned, 'Rule-based (tuned)'), ...
             make_policy_fixed(1, 'Efficiency-only'), ...
             make_policy_fixed(6, 'Always-cautious') };
end
