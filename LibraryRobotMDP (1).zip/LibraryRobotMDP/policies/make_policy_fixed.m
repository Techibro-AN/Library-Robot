function pol = make_policy_fixed(a, name)
%MAKE_POLICY_FIXED  Policy that always takes action a.
%   make_policy_fixed(1, 'Efficiency-only')  -> always (vmax, shortest)
%   make_policy_fixed(6, 'Always-cautious')  -> always (vst, detour)
pol.name = name;
pol.init = [];
pol.act  = @(s, mem) deal(a, mem);
end
