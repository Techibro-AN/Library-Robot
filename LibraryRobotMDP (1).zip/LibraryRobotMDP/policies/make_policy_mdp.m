function pol = make_policy_mdp(model, name)
%MAKE_POLICY_MDP  Wrap a solved model's policy as a policy struct.
%   Policy interface (all baselines): pol.name, pol.init (memory),
%   [a, mem] = pol.act(s, mem) with s = [xa xm xp xc xtd].
if nargin < 2, name = 'MDP'; end
P = model.P;  piStar = model.policy;
pol.name = name;
pol.init = [];
pol.act  = @(s, mem) deal(piStar(state_index(s, P)), mem);
end
