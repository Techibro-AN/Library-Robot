function [pol, model0] = make_policy_myopic(P)
%MAKE_POLICY_MYOPIC  One-step greedy baseline (gamma = 0, same reward and model).
%   Isolates the contribution of lookahead: identical to the MDP except that
%   future consequences are ignored.
P.gamma = 0;
model0 = solve_mdp(P);
pol = make_policy_mdp(model0, 'Myopic (\gamma=0)');
end
