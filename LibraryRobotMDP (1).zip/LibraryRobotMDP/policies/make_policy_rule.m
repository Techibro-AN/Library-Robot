function pol = make_policy_rule(th, name)
%MAKE_POLICY_RULE  Rule-based baseline with thresholds th (see rule_based_action).
if nargin < 1 || isempty(th), th = rule_params_default(); end
if nargin < 2, name = 'Rule-based'; end
pol.name = name;
pol.th   = th;
pol.init = struct('count', 0, 'route', 1);
pol.act  = @(s, mem) rule_based_action(s, mem, th);
end
