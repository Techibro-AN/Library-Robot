function [a, mem] = rule_based_action(s, mem, th)
%RULE_BASED_ACTION  Fully specified if-then baseline (reviewer 2, comment 6).
%   Rules, evaluated in order (risk = xa*xp, route = detour if xc >= th.crowd
%   or (th.mobileDetour and xm = 1), otherwise widen):
%     R1  xa = 0                       -> (vmax, shortest)       [reset memory]
%     R2  risk >= th.riskHigh          -> (vst,  route)          [memory = th.hold]
%     R3  risk >= th.riskLow           -> (vmax, route)          [memory = th.hold]
%     R4  otherwise (focused patron, far zone):
%           memory > 0 (hysteresis)    -> (vmax, last route), memory - 1
%           memory = 0                 -> (vmax, shortest)
%   With th.hold = 0 the policy is purely reactive (the paper's original
%   rule-based method); with th.hold > 0 it keeps its avoidance route for a
%   few epochs, which removes the approach/retreat oscillation.
%   Action indices: 1 vmax-sh, 2 vmax-wd, 3 vmax-dt, 4 vst-sh, 5 vst-wd, 6 vst-dt, 7 hold.
xa = s(1); xm = s(2); xp = s(3); xc = s(4);
if isempty(mem), mem = struct('count', 0, 'route', 1); end
if xc >= th.crowd || (th.mobileDetour && xm == 1), route = 3; else, route = 2; end
risk = xa * xp;
if xa == 0
    a = 1;  mem.count = 0;
elseif risk >= th.riskHigh
    a = 3 + route;  mem.count = th.hold;  mem.route = route;
elseif risk >= th.riskLow
    a = route;      mem.count = th.hold;  mem.route = route;
elseif mem.count > 0
    a = mem.route;  mem.count = mem.count - 1;
else
    a = 1;
end
end
