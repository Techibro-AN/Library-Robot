function th = rule_params_default()
%RULE_PARAMS_DEFAULT  Thresholds of the rule-based baseline (reactive version).
%   risk = xa * xp  (joint attention-proximity level, 0..4)
%   th.riskHigh   risk >= riskHigh -> stealth velocity + avoidance route
%   th.riskLow    risk >= riskLow  -> standard velocity + avoidance route
%   th.crowd      crowd level at/above which widening is replaced by detour
%   th.mobileDetour  true: a mobile patron always triggers detour instead of widen
%   th.hold       hysteresis: number of epochs the avoidance route is kept
%                 after the risk drops to zero while the patron is still
%                 focused (0 = purely reactive, as in the original paper)
th.riskHigh = 2;
th.riskLow  = 1;
th.crowd    = 2;
th.mobileDetour = true;
th.hold     = 0;
end
