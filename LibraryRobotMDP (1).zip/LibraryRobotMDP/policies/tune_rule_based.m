function [thBest, results] = tune_rule_based(P, nEpisodes, seed, grid)
%TUNE_RULE_BASED  Grid search of the rule-based thresholds (fair baseline).
%   Every threshold combination is evaluated by Monte Carlo on the same
%   objective the MDP optimizes (mean discounted return). Use a seed that
%   differs from the final evaluation seed to avoid tuning on test episodes.
%   results is an array of structs (th, meanReturn, ci95), best first.
if nargin < 2, nEpisodes = 500; end
if nargin < 3, seed = P.seed + 1000; end
if nargin < 4
    grid.riskHigh = [1 2 3 4];
    grid.riskLow  = [1 2];
    grid.crowd    = [1 2 3];          % 3 = never force detour because of crowd
    grid.mobileDetour = [false true];
    grid.hold     = [0 1 2 3 5];
end
k = 0;
for rh = grid.riskHigh
 for rl = grid.riskLow
  if rl > rh, continue; end
  for cr = grid.crowd
   for md = grid.mobileDetour
    for h = grid.hold
      th = struct('riskHigh', rh, 'riskLow', rl, 'crowd', cr, 'mobileDetour', md, 'hold', h);
      MC = run_monte_carlo({make_policy_rule(th)}, P, nEpisodes, seed);
      k = k + 1;
      results(k).th = th; %#ok<AGROW>
      results(k).meanReturn = MC.summary.returnDisc.mean;
      results(k).ci95 = MC.summary.returnDisc.ci95;
    end
   end
  end
 end
end
[~, order] = sort([results.meanReturn], 'descend');
results = results(order);
thBest = results(1).th;
end
