%RUN_PHASEB  Build, verify and solve the revised MDP; build and tune all baselines;
%   smoke-test the simulation pipeline; export the model for the supplement.
%
%   Phase B tasks:  7 implement revised model | 8 reproducibility (solver
%   settings, seeds, versions, exported matrices) | 9 fully specified and
%   tuned baselines | 10 quantitative metrics.
%   Outputs (folder results/):  phaseB.mat, model_export/*.csv, phaseB_log.txt
%
%   Runs in MATLAB (R2019b or later) and GNU Octave (8.x).

clear; clc;
root = setup_paths();
outDir = fullfile(root, 'results');
if ~exist(outDir, 'dir'), mkdir(outDir); end
diary(fullfile(outDir, 'phaseB_log.txt')); diary on;

%% 1. Parameters and environment (task 8)
P = params_default();
env = env_info(P);
fprintf('Platform: %s %s | seed %d | %s\n', env.platform, env.version, env.seed, env.date);

%% 2. Build and solve the MDP (task 7)
model = solve_mdp(P);
fprintf('\nStates: %d (%d non-terminal + terminal) | actions: %d\n', P.nS, P.nActive, P.nA);
fprintf('Value iteration: V0 = 0, tolerance %.2e (epsilon = %.0e), %d iterations, %.3f s, converged = %d\n', ...
        model.info.tolerance, P.vi.epsilon, model.info.iterations, model.info.runtime_s, model.info.converged);

%% 3. Consistency checks
rep = check_model(model, 20000, P.seed);
fprintf('Checks passed: max row-sum error %.1e | simulator-vs-model TV distance max %.4f | Bellman residual %.1e\n', ...
        rep.maxRowSumError, max(rep.simulatorTVdist), rep.bellmanResidual);

%% 4. Policy across the state space (input for Results section 'Policy behavior')
S = policy_summary(model);
fprintf('\nOptimal action share (%%) by attention level:\n%-10s', '');
fprintf('%15s', S.actionNames{:}); fprintf('\n');
lvl = {'xa=0','xa=1','xa=2'};
for k = 1:3, fprintf('%-10s', lvl{k}); fprintf('%15.1f', S.byAttention(k,:)); fprintf('\n'); end
lvl = {'xp=0','xp=1','xp=2'};
fprintf('By proximity:\n');
for k = 1:3, fprintf('%-10s', lvl{k}); fprintf('%15.1f', S.byProximity(k,:)); fprintf('\n'); end

%% 5. Baselines (task 9): tune the rule-based thresholds on separate episodes
fprintf('\nTuning rule-based thresholds (grid search, seed %d)...\n', P.seed + 1000);
[thTuned, tuneRes] = tune_rule_based(P, 300, P.seed + 1000);
fprintf('Best thresholds: riskHigh=%d riskLow=%d crowd=%d mobileDetour=%d hold=%d (return %.2f)\n', ...
        thTuned.riskHigh, thTuned.riskLow, thTuned.crowd, thTuned.mobileDetour, thTuned.hold, tuneRes(1).meanReturn);
policies = make_baselines(model, thTuned);
names = cellfun(@(p) p.name, policies, 'UniformOutput', false);

%% 6. Smoke test of the evaluation pipeline (task 10) - full runs are Phase C
scen = define_scenarios(P);
for k = 1:numel(scen)
    [logs, met] = run_scenario(scen(k), policies, P, P.seed + k);
    fprintf('\n%s\n', scen(k).name);
    print_metrics_table(names, met);
end
MC = run_monte_carlo(policies, P, 200, P.seed);
fprintf('\nMonte Carlo smoke test (%d episodes, mean +- 95%% CI):\n', MC.nEpisodes);
print_metrics_table(names, MC.summary, true);

%% 7. Export (task 8)
export_model(model, fullfile(outDir, 'model_export'));
save(fullfile(outDir, 'phaseB.mat'), 'P', 'model', 'env', 'rep', 'S', 'thTuned', 'tuneRes', 'MC');
fprintf('\nSaved results to %s\n', outDir);
diary off;
