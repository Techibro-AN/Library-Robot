%RUN_PHASEC  All Phase C simulations; writes every figure and table for the Results section.
%
%   Task 11  policy across the state space        -> fig_policy_shares.png, policy_shares.csv
%   Task 12  four trajectory scenarios            -> scenarios.csv, fig_traj_S1..S4.png, scenario_metrics_S1..S4.csv
%   Task 13  Monte Carlo + paired tests           -> mc_summary.csv, mc_paired_tests.csv
%            sensitivity analysis                 -> sensitivity.csv, sensitivity_sweep.csv, fig_sensitivity_wd.png
%   Task 14  second environment (exam season)     -> exam_mc_summary.csv, exam_policy_change.txt, fig_traj_exam.png
%   Key numbers for the text                      -> phaseC_key_numbers.txt ;  everything -> phaseC.mat
%
%   Before running: check define_scenarios.m (task 12) and env_exam_season.m
%   (task 14) match what you want to report. Run run_phaseB.m first (it
%   provides the tuned rule-based thresholds); otherwise they are re-tuned.

clear; clc;
root = setup_paths();
cfg.nMC         = 1000;      % Monte Carlo episodes (main comparison and exam season)
cfg.nMCsens     = 1000;      % Monte Carlo episodes per sensitivity variant
cfg.trajPolicies = [1 3 4];  % policies drawn in trajectory figures: MDP, reactive, tuned rule
outDir = fullfile(root, 'results', 'phaseC');
if ~exist(outDir, 'dir'), mkdir(outDir); end
diary(fullfile(outDir, 'phaseC_log.txt')); diary on;
if exist('OCTAVE_VERSION', 'builtin') && isempty(getenv('DISPLAY')), graphics_toolkit('gnuplot'); end

%% 0. Model, environment info and baselines
P = params_default();
env = env_info(P);
fprintf('Phase C | %s %s | seed %d | %s\n', env.platform, env.version, P.seed, env.date);
model = solve_mdp(P);
fB = fullfile(root, 'results', 'phaseB.mat');
if exist(fB, 'file')
    tmp = load(fB, 'thTuned');  thTuned = tmp.thTuned;
    fprintf('Using tuned rule-based thresholds from Phase B.\n');
else
    fprintf('phaseB.mat not found: tuning rule-based thresholds...\n');
    thTuned = tune_rule_based(P, 300, P.seed + 1000);
end
policies = make_baselines(model, thTuned);
names = cellfun(@(p) p.name, policies, 'UniformOutput', false);
K = fopen(fullfile(outDir, 'phaseC_key_numbers.txt'), 'w');
fprintf(K, 'Platform %s %s, seed %d, value iteration %d iterations (tol %.2e)\n', ...
        env.platform, env.version, P.seed, model.info.iterations, model.info.tolerance);
fprintf(K, 'Tuned rule thresholds: riskHigh=%d riskLow=%d crowd=%d mobileDetour=%d hold=%d\n\n', ...
        thTuned.riskHigh, thTuned.riskLow, thTuned.crowd, thTuned.mobileDetour, thTuned.hold);

%% Task 11. Policy behavior across the state space
S = policy_summary(model);
grpLab = {'xa=0','xa=1','xa=2','xp=0','xp=1','xp=2','xm=0','xm=1','xc=0','xc=1','xc=2','all'};
write_csv(fullfile(outDir, 'policy_shares.csv'), [{'group'}, S.actionNames], grpLab, ...
          [S.byAttention; S.byProximity; S.byMobility; S.byCrowd; S.overall]);
plot_policy_summary(S, fullfile(outDir, 'fig_policy_shares.png'));
fprintf(K, '[Task 11] Optimal action shares (%%), columns: %s\n', strjoin(S.actionNames, ', '));
for k = 1:numel(grpLab)
    M = [S.byAttention; S.byProximity; S.byMobility; S.byCrowd; S.overall];
    fprintf(K, '  %-5s %s\n', grpLab{k}, sprintf('%6.1f', M(k, :)));
end

%% Task 12. Trajectory scenarios
scen = define_scenarios(P);
lev = @describe_script;
fid = fopen(fullfile(outDir, 'scenarios.csv'), 'w');
fprintf(fid, 'scenario,xa0,xm0,xp0,xc0,xtd0,attention,mobility,crowd,epochs\n');
for k = 1:numel(scen)
    fprintf(fid, '"%s",%d,%d,%d,%d,%d,"%s","%s","%s",%d\n', scen(k).name, scen(k).s0, ...
            lev(scen(k).script.xa), lev(scen(k).script.xm), lev(scen(k).script.xc), scen(k).nEpochs);
end
fclose(fid);
metricCols = {'returnDisc','tasksCompleted','completionTime','intrusions','severeIntrusions', ...
              'disturbance','noiseExposure','actionSwitches','proxReversals','meanSpeed','extraPath'};
fprintf(K, '\n[Task 12] Scenario results (columns: %s)\n', strjoin(metricCols, ', '));
scenLogs = cell(1, numel(scen));  scenMet = cell(1, numel(scen));
for k = 1:numel(scen)
    [logs, met] = run_scenario(scen(k), policies, P, P.seed + k);
    scenLogs{k} = logs;  scenMet{k} = met;
    X = cell2mat(cellfun(@(c) [met.(c)]', metricCols, 'UniformOutput', false));
    write_csv(fullfile(outDir, sprintf('scenario_metrics_S%d.csv', k)), [{'policy'}, metricCols], names, X);
    plot_trajectories(logs(cfg.trajPolicies), scen(k).name, P, fullfile(outDir, sprintf('fig_traj_S%d.png', k)));
    export_trajectory_csv(logs, cfg.trajPolicies, P, fullfile(outDir, sprintf('traj_S%d', k)));
    fprintf(K, '  %s\n', scen(k).name);
    for j = 1:numel(names), fprintf(K, '    %-24s %s\n', names{j}, sprintf('%9.2f', X(j, :))); end
    fprintf('\n%s\n', scen(k).name);  print_metrics_table(names, met);
end
close all;

%% Task 13a. Monte Carlo comparison with paired tests
fprintf('\nMonte Carlo: %d episodes x %d policies...\n', cfg.nMC, numel(policies));
MC = run_monte_carlo(policies, P, cfg.nMC, P.seed);
print_metrics_table(names, MC.summary, true);
hdr = {'policy'};  Xs = [];
for c = metricCols
    hdr = [hdr, {[c{1} '_mean'], [c{1} '_ci95']}]; %#ok<AGROW>
    Xs = [Xs, MC.summary.(c{1}).mean', MC.summary.(c{1}).ci95']; %#ok<AGROW>
end
write_csv(fullfile(outDir, 'mc_summary.csv'), hdr, names, Xs);
testCols = {'returnDisc','intrusions','severeIntrusions','disturbance','completionTime','actionSwitches','proxReversals'};
fid = fopen(fullfile(outDir, 'mc_paired_tests.csv'), 'w');
fprintf(fid, 'metric,baseline,n,mean_diff_MDP_minus_baseline,ci_low,ci_high,t,p,effect_size_dz\n');
fprintf(K, '\n[Task 13] Monte Carlo (%d episodes): mean (95%% CI)\n', cfg.nMC);
for j = 1:numel(names)
    fprintf(K, '  %-24s return %.2f (+-%.2f) | intrusions %.3f | severe %.3f | completion %.2f | switches %.2f | reversals %.2f\n', ...
        names{j}, MC.summary.returnDisc.mean(j), MC.summary.returnDisc.ci95(j), MC.summary.intrusions.mean(j), ...
        MC.summary.severeIntrusions.mean(j), MC.summary.completionTime.mean(j), ...
        MC.summary.actionSwitches.mean(j), MC.summary.proxReversals.mean(j));
end
fprintf(K, '  Paired tests MDP vs baseline (difference, p):\n');
for c = testCols
    for j = 2:numel(names)
        T = paired_test(MC.metric.(c{1})(:, 1), MC.metric.(c{1})(:, j));
        fprintf(fid, '%s,"%s",%d,%.6g,%.6g,%.6g,%.4g,%.4g,%.4g\n', c{1}, names{j}, T.n, ...
                T.meanDiff, T.ci95, T.t, T.p, T.dz);
        fprintf(K, '    %-17s vs %-24s %9.3f  p=%.3g\n', c{1}, names{j}, T.meanDiff, T.p);
    end
end
fclose(fid);

%% Task 13b. Sensitivity analysis
fprintf('\nSensitivity analysis (%d variants)...\n', 17);
[Sens, sweep] = sensitivity_analysis(P, model, cfg.nMCsens, P.seed);
write_csv(fullfile(outDir, 'sensitivity.csv'), [{'variant'}, Sens.columns], Sens.labels, Sens.data);
write_csv(fullfile(outDir, 'sensitivity_sweep.csv'), {'w_d','stealth_share','detour_share'}, [], ...
          [sweep.wd', sweep.stealthShare', sweep.detourShare']);
plot_sensitivity_sweep(sweep, P.w.d, fullfile(outDir, 'fig_sensitivity_wd.png'));
close all;
fprintf(K, '\n[Task 13] Sensitivity (columns: %s)\n', strjoin(Sens.columns, ', '));
for k = 1:numel(Sens.labels)
    fprintf(K, '  %-24s %s\n', Sens.labels{k}, sprintf('%9.2f', Sens.data(k, :)));
end
stIdx = sweep.wd(sweep.stealthShare > 0);
if isempty(stIdx)
    fprintf(K, '  Stealth is never optimal for w_d in [%g, %g]\n', sweep.wd(1), sweep.wd(end));
else
    fprintf(K, '  Stealth is optimal in some states for w_d in [%g, %g] (sweep %g:%g)\n', ...
            min(stIdx), max(stIdx), sweep.wd(1), sweep.wd(end));
end

%% Task 14. Second environment: exam season
Pe = env_exam_season(P);
modelE = solve_mdp(Pe);
chg = 100 * mean(modelE.policy(1:P.nActive) ~= model.policy(1:P.nActive));
polE = [{make_policy_mdp(modelE, 'MDP (re-solved, exam)'), make_policy_mdp(model, 'MDP (nominal model)')}, policies(2:end)];
namesE = cellfun(@(p) p.name, polE, 'UniformOutput', false);
MCe = run_monte_carlo(polE, Pe, cfg.nMC, P.seed + 500);
fprintf('\nExam season Monte Carlo:\n');  print_metrics_table(namesE, MCe.summary, true);
Xe = [];
for c = metricCols, Xe = [Xe, MCe.summary.(c{1}).mean', MCe.summary.(c{1}).ci95']; end %#ok<AGROW>
write_csv(fullfile(outDir, 'exam_mc_summary.csv'), hdr, namesE, Xe);
Se = policy_summary(modelE);
fid = fopen(fullfile(outDir, 'exam_policy_change.txt'), 'w');
fprintf(fid, 'Optimal action changed in %.1f%% of states when re-solved for the exam-season environment.\n', chg);
fprintf(fid, 'Overall action shares nominal: %s\nOverall action shares exam:    %s\n', ...
        sprintf('%6.1f', S.overall), sprintf('%6.1f', Se.overall));
fclose(fid);
scE = scen(4);  scE.name = 'Exam season environment';  scE.script.xm = nan(1, scE.nEpochs);
[logsE, ~] = run_scenario(scE, polE([1 2 4 5]), Pe, P.seed + 40);
plot_trajectories(logsE, scE.name, Pe, fullfile(outDir, 'fig_traj_exam.png'));
close all;
fprintf(K, '\n[Task 14] Exam season: policy changed in %.1f%% of states\n', chg);
for j = 1:numel(namesE)
    fprintf(K, '  %-24s return %.2f (+-%.2f) | intrusions %.3f | completion %.2f | reversals %.2f\n', namesE{j}, ...
        MCe.summary.returnDisc.mean(j), MCe.summary.returnDisc.ci95(j), MCe.summary.intrusions.mean(j), ...
        MCe.summary.completionTime.mean(j), MCe.summary.proxReversals.mean(j));
end
T = paired_test(MCe.metric.returnDisc(:, 1), MCe.metric.returnDisc(:, 2));
fprintf(K, '  Re-solved vs nominal MDP in exam season: return difference %.3f (p=%.3g)\n', T.meanDiff, T.p);
fclose(K);

save(fullfile(outDir, 'phaseC.mat'), 'P', 'Pe', 'model', 'modelE', 'env', 'thTuned', 'S', 'Se', ...
     'scen', 'scenMet', 'MC', 'MCe', 'Sens', 'sweep', 'cfg');
fprintf('\nPhase C complete. Results in %s\n', outDir);
diary off;

