function root = setup_paths()
%SETUP_PATHS  Add all code folders to the MATLAB/Octave path. Returns the project root.
root = fileparts(mfilename('fullpath'));
addpath(fullfile(root, 'model'), fullfile(root, 'solver'), fullfile(root, 'policies'), ...
        fullfile(root, 'simulation'), fullfile(root, 'utils'));
end
