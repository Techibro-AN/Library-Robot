function m = compute_metrics(L, P)
%COMPUTE_METRICS  Quantitative evaluation metrics for one simulated episode.
%   returnDisc        discounted return  sum_t gamma^(t-1) r_t
%   returnTotal       undiscounted return
%   tasksCompleted    number of completed tasks
%   completionTime    epochs until the first task completion (NaN if none)
%   intrusions        epochs in the intimate zone with a focused patron (xa>=1 & xp=2)
%   severeIntrusions  epochs in the intimate zone with a deeply focused patron (xa=2 & xp=2)
%   disturbance       cumulative attention-proximity exposure  sum g(xa,xp)
%   noiseExposure     cumulative noise exposure  sum g(xa,xp)*n_l(v)
%   actionSwitches    number of epochs where the action differs from the previous one
%   proxReversals     number of direction changes of the proximity zone (oscillation)
%                     (both counted within tasks, not across a task restart)
%   meanSpeed         mean commanded speed [m/s]
%   extraPath         mean extra path length of the chosen routes
N = L.nSteps;
g = disturbance_level(L.xa, L.xp, P);
m.returnDisc       = sum(P.gamma .^ (0:N-1)' .* L.reward);
m.returnTotal      = sum(L.reward);
m.tasksCompleted   = sum(L.completed);
k = find(L.completed, 1, 'first');
if isempty(k), m.completionTime = NaN; else, m.completionTime = k; end
m.intrusions       = sum(L.xa >= 1 & L.xp == 2);
m.severeIntrusions = sum(L.xa == 2 & L.xp == 2);
m.disturbance      = sum(g);
m.noiseExposure    = sum(g .* P.act.nl(L.a)');
% oscillation metrics are counted within each task only (a new task resets xp)
task = cumsum([0; L.completed(1:end-1)]);
m.actionSwitches   = 0;
m.proxReversals    = 0;
for k = unique(task)'
    idx = find(task == k);
    m.actionSwitches = m.actionSwitches + sum(diff(L.a(idx)) ~= 0);
    dxp = diff(L.xp(idx));  dxp = dxp(dxp ~= 0);
    m.proxReversals  = m.proxReversals + sum(diff(sign(dxp)) ~= 0);
end
m.meanSpeed        = mean(P.act.speed(L.a));
m.extraPath        = mean(P.act.dl(L.a));
end
