function S = define_scenarios(P)
%DEFINE_SCENARIOS  The four trajectory scenarios (reviewer 1, comment 2).
%   Each scenario fixes the initial state and, where stated, scripts the
%   exogenous variables epoch by epoch (NaN = evolve by the Markov chain).
%   All scenarios start a task at the far zone (xp = 0, xtd = n) and start a
%   new task whenever one is completed, so that all policies are compared
%   over the same 50 epochs.
%   >> Adjust these definitions so they match the scenarios described in the
%      paper's Results section, then report them in a scenario table. <<
N = P.sim.nEpochs;
z = zeros(1, N);  o = ones(1, N);  u = nan(1, N);

% S1: distracted, stationary patron in an isolated area
S(1) = mk('S1: distracted patron', [0 0 0 0 P.n], z, z, z, N);

% S2: attention increasing (paper Fig. 5): distracted -> moderately -> deeply focused
xa = [zeros(1,15), ones(1,15), 2*ones(1,N-30)];
S(2) = mk('S2: attention increasing', [0 0 0 0 P.n], xa, z, u, N);

% S3: mobile, deeply focused patron in a moderately crowded area
S(3) = mk('S3: mobile focused patron', [2 1 0 1 P.n], 2*o, o, o, N);

% S4: exam season - deeply focused patron, crowded area, mobility stochastic
S(4) = mk('S4: crowded exam season', [2 0 0 2 P.n], 2*o, u, 2*o, N);
end

function s = mk(name, s0, xa, xm, xc, N)
s.name = name;
s.s0 = s0;
s.nEpochs = N;
s.script = struct('xa', xa, 'xm', xm, 'xc', xc);
s.restartOnComplete = true;
s.xpOnRestart = 0;
end
