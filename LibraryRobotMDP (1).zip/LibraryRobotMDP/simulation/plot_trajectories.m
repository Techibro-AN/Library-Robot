function fig = plot_trajectories(logs, titleStr, P, outFile)
%PLOT_TRAJECTORIES  Multi-panel trajectory plot: attention, proximity, velocity, routing.
%   logs = cell array of simulate_episode logs (one per policy) for the
%   same scenario. Saves a 300-dpi PNG if outFile is given.
vis = 'on';
if exist('OCTAVE_VERSION', 'builtin') && isempty(getenv('DISPLAY')), vis = 'off'; end
fig = figure('Color', 'w', 'Position', [100 100 900 800], 'Visible', vis);
panels = {'Attention x_a', 'Proximity x_p', 'Velocity', 'Routing'};
yt = {{'distracted','moderate','deep'}, {'far','near','intimate'}, ...
      {'v_{max}','v_{st}','v_0'}, {'none','shortest','widen','detour'}};
styles = {'-', '--', ':', '-.', '-', '--'};
for p = 1:4
    subplot(4, 1, p); hold on; box on;
    for k = 1:numel(logs)
        L = logs{k};
        switch p
            case 1, y = L.xa;
            case 2, y = L.xp;
            case 3, y = P.act.vel(L.a)';
            case 4, y = P.act.rho(L.a)';
        end
        stairs(1:L.nSteps, y, styles{mod(k-1, numel(styles)) + 1}, 'LineWidth', 1.6);
        if p == 1, break; end            % attention is common to all policies
    end
    switch p
        case 1, set(gca, 'YTick', 0:2, 'YTickLabel', yt{1}); ylim([-0.3 2.3]);
        case 2, set(gca, 'YTick', 0:2, 'YTickLabel', yt{2}); ylim([-0.3 2.3]);
        case 3, set(gca, 'YTick', 1:3, 'YTickLabel', yt{3}); ylim([0.7 3.3]);
        case 4, set(gca, 'YTick', 0:3, 'YTickLabel', yt{4}); ylim([-0.3 3.3]);
    end
    ylabel(panels{p}); set(gca, 'FontSize', 11);
    if p > 1
        legend(cellfun(@(L) L.policy, logs, 'UniformOutput', false), 'Location', 'eastoutside');
    end
    if p == 1, title(titleStr); end
end
xlabel('Decision epoch');
if nargin > 3 && ~isempty(outFile)
    print(fig, outFile, '-dpng', '-r300');
end
end
