function MC = run_monte_carlo(policies, P, nEpisodes, seed)
%RUN_MONTE_CARLO  Monte Carlo evaluation with common random numbers.
%   Each episode starts a task (xtd = n) from a uniformly random
%   (xa, xm, xp, xc); exogenous variables follow their Markov chains; an
%   episode ends at task completion or after P.sim.maxEpochsMC epochs.
%   Every policy sees the same initial states and the same random draws.
%
%   MC.metric.(name) is nEpisodes-by-nPolicies; MC.summary gives mean, std
%   and 95% confidence half-width for each metric and policy.
rng(seed);
N = P.sim.maxEpochsMC;
S0 = [randi([0 2], nEpisodes, 1), randi([0 1], nEpisodes, 1), ...
      randi([0 2], nEpisodes, 1), randi([0 2], nEpisodes, 1), P.n * ones(nEpisodes, 1)];
U = rand(N, 5, nEpisodes);
nP = numel(policies);
scen.nEpochs = N;  scen.restartOnComplete = false;  scen.name = 'MonteCarlo';
for e = 1:nEpisodes
    scen.s0 = S0(e, :);
    for k = 1:nP
        L = simulate_episode(scen, policies{k}, P, U(:, :, e));
        m = compute_metrics(L, P);
        f = fieldnames(m);
        for j = 1:numel(f)
            MC.metric.(f{j})(e, k) = m.(f{j});
        end
    end
end
MC.policyNames = cellfun(@(p) p.name, policies, 'UniformOutput', false);
MC.nEpisodes = nEpisodes;  MC.seed = seed;  MC.initialStates = S0;
f = fieldnames(MC.metric);
for j = 1:numel(f)
    X = MC.metric.(f{j});
    [mu, sd, nv] = nan_stats(X);
    MC.summary.(f{j}).mean = mu;
    MC.summary.(f{j}).std  = sd;
    MC.summary.(f{j}).n    = nv;
    MC.summary.(f{j}).ci95 = 1.96 * sd ./ sqrt(nv);
end
end

function [mu, sd, nv] = nan_stats(X)
% column-wise mean/std ignoring NaN (works in MATLAB and Octave)
nv = sum(~isnan(X), 1);
X0 = X;  X0(isnan(X0)) = 0;
mu = sum(X0, 1) ./ nv;
D = X - mu;  D(isnan(D)) = 0;
sd = sqrt(sum(D.^2, 1) ./ max(nv - 1, 1));
end
