function [logs, metrics] = run_scenario(scen, policies, P, seed)
%RUN_SCENARIO  Run every policy on one scenario with identical random draws.
%   logs{k} and metrics(k) correspond to policies{k}.
rng(seed);
U = rand(scen.nEpochs, 5);           % common random numbers for all policies
nP = numel(policies);
logs = cell(1, nP);
for k = 1:nP
    logs{k} = simulate_episode(scen, policies{k}, P, U);
    metrics(k) = compute_metrics(logs{k}, P); %#ok<AGROW>
end
end
