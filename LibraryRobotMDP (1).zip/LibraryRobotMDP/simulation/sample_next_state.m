function sn = sample_next_state(s, a, u, P, fixed)
%SAMPLE_NEXT_STATE  Draw s' ~ P(.|s,a) using pre-drawn uniforms (common random numbers).
%   s     current state [xa xm xp xc xtd] (non-terminal)
%   a     action index
%   u     1x5 uniforms in (0,1): [attention mobility crowd proximity progress]
%   fixed struct with optional scripted next values: fixed.xa, fixed.xm,
%         fixed.xc (NaN or missing -> sampled from the Markov chain)
%   Uses exactly the same component distributions as build_transition_model,
%   so simulated trajectories are consistent with the solved MDP.
xa = s(1); xm = s(2); xp = s(3); xc = s(4); xtd = s(5);
ka = pick(P.Pa(xa+1, :), u(1));
km = pick(P.Pm(xm+1, :), u(2));
kc = pick(P.Pc(xc+1, :), u(3));
if isfield(fixed, 'xa') && ~isnan(fixed.xa), ka = fixed.xa; end
if isfield(fixed, 'xm') && ~isnan(fixed.xm), km = fixed.xm; end
if isfield(fixed, 'xc') && ~isnan(fixed.xc), kc = fixed.xc; end
kp = pick(prox_distribution(xp, xm, xc, a, P), u(4));
ktd = xtd - double(u(5) < P.act.p(a));
sn = [ka km kp kc ktd];
end

function k = pick(p, u)
% inverse-CDF sampling, returns 0-based value
k = find(u < cumsum(p), 1, 'first') - 1;
if isempty(k), k = numel(p) - 1; end
end
