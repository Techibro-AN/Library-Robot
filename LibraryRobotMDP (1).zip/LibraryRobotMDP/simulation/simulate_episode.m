function log = simulate_episode(scen, pol, P, U)
%SIMULATE_EPISODE  Run one policy through one scenario with given random draws.
%   scen  scenario struct (see define_scenarios):
%           .s0                initial state [xa xm xp xc xtd]
%           .nEpochs           number of decision epochs
%           .script.xa/.xm/.xc vectors (length nEpochs) of scripted values,
%                              NaN entries (or empty) -> Markov chain
%           .restartOnComplete true: a new task starts on completion
%                              (xtd = n, xp = .xpOnRestart); false: stop
%   pol   policy struct (make_policy_*)
%   U     nEpochs-by-5 uniforms (shared across policies -> common random numbers)
%   Returns a log struct with per-epoch arrays (state before the action,
%   action, cost components, reward) and completion information.
N = scen.nEpochs;
L.xa = nan(N,1); L.xm = L.xa; L.xp = L.xa; L.xc = L.xa; L.xtd = L.xa;
L.a = L.xa; L.reward = L.xa; L.disruption = L.xa; L.np = L.xa; L.mp = L.xa;
L.rp = L.xa; L.dp = L.xa; L.completed = false(N,1);
s = apply_script(scen.s0, scen, 1);
mem = pol.init;
nSteps = 0;
for t = 1:N
    [a, mem] = pol.act(s, mem);
    c = cost_terms(s, a, P);
    fixed = script_at(scen, t + 1);
    sn = sample_next_state(s, a, U(t, :), P, fixed);
    done = sn(5) == 0;
    r = -c.disruption - c.C + P.w.T * done;
    L.xa(t) = s(1); L.xm(t) = s(2); L.xp(t) = s(3); L.xc(t) = s(4); L.xtd(t) = s(5);
    L.a(t) = a; L.reward(t) = r; L.disruption(t) = c.disruption;
    L.np(t) = c.np; L.mp(t) = c.mp; L.rp(t) = c.rp; L.dp(t) = c.dp;
    L.completed(t) = done;
    nSteps = t;
    if done
        if isfield(scen, 'restartOnComplete') && scen.restartOnComplete
            sn(5) = P.n;                         % new task
            sn(3) = scen.xpOnRestart;
            mem = pol.init;
        else
            break;
        end
    end
    s = sn;
end
f = fieldnames(L);
for k = 1:numel(f), L.(f{k}) = L.(f{k})(1:nSteps); end
L.nSteps = nSteps;
L.policy = pol.name;
L.scenario = scen.name;
log = L;
end

function s = apply_script(s, scen, t)
fx = script_at(scen, t);
if ~isnan(fx.xa), s(1) = fx.xa; end
if ~isnan(fx.xm), s(2) = fx.xm; end
if ~isnan(fx.xc), s(4) = fx.xc; end
end

function fx = script_at(scen, t)
fx = struct('xa', NaN, 'xm', NaN, 'xc', NaN);
if ~isfield(scen, 'script'), return; end
names = {'xa', 'xm', 'xc'};
for k = 1:3
    nm = names{k};
    if isfield(scen.script, nm) && ~isempty(scen.script.(nm)) && t <= numel(scen.script.(nm))
        fx.(nm) = scen.script.(nm)(t);
    end
end
end
