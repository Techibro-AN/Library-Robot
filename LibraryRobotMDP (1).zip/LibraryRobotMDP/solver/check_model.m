function report = check_model(model, nSamples, seed)
%CHECK_MODEL  Consistency checks on a solved model.
%   1. every T{a} is row-stochastic and non-negative;
%   2. the terminal state is absorbing with zero reward;
%   3. state_index / state_from_index are inverse maps;
%   4. the simulator's sampling step reproduces T (empirical vs. exact
%      next-state distribution for random (s,a) pairs, total-variation distance);
%   5. the Bellman residual of the returned V is below tolerance.
%   Throws an error if any check fails; returns a struct of diagnostics.
if nargin < 2, nSamples = 20000; end
if nargin < 3, seed = model.P.seed; end
P = model.P;  T = model.T;

maxRowErr = 0; minEntry = Inf;
for a = 1:P.nA
    maxRowErr = max(maxRowErr, max(abs(full(sum(T{a}, 2)) - 1)));
    minEntry  = min(minEntry, min(nonzeros(T{a})));
end
assert(maxRowErr < 1e-12, 'Rows of T do not sum to 1 (max error %.2e).', maxRowErr);
assert(minEntry >= 0, 'Negative transition probability.');
for a = 1:P.nA
    assert(T{a}(P.sT, P.sT) == 1 && nnz(T{a}(P.sT, :)) == 1, 'Terminal state is not absorbing.');
end
assert(all(model.R(P.sT, :) == 0), 'Terminal state must have zero reward.');

idx = (1:P.nS)';
assert(isequal(state_index(state_from_index(idx, P), P), idx), 'State index maps are inconsistent.');

% simulator vs. exact kernel
rng(seed);
tv = zeros(5, 1);
for k = 1:5
    i = randi(P.nActive);  a = randi(P.nA);
    s = state_from_index(i, P);
    counts = zeros(1, P.nS);
    for n = 1:nSamples
        sn = sample_next_state(s, a, rand(1, 5), P, struct());
        j = state_index(sn, P);
        counts(j) = counts(j) + 1;
    end
    tv(k) = 0.5 * sum(abs(counts / nSamples - full(T{a}(i, :))));
end
assert(all(tv < 0.03), 'Simulator does not match T (TV distance %.3f).', max(tv));

% Bellman residual
Qchk = zeros(P.nS, P.nA);
for a = 1:P.nA, Qchk(:, a) = model.R(:, a) + P.gamma * (T{a} * model.V); end
bellRes = max(abs(max(Qchk, [], 2) - model.V));

report.maxRowSumError     = maxRowErr;
report.simulatorTVdist    = tv';
report.bellmanResidual    = bellRes;
report.nStates            = P.nS;
report.nActions           = P.nA;
report.nonzerosPerAction  = cellfun(@nnz, T);
end
