function [Tab, sweep] = sensitivity_analysis(P, modelNom, nMC, seed)
%SENSITIVITY_ANALYSIS  Robustness of the optimal policy to modelling choices (R2-5).
%   Variants: each reward weight x0.5 and x1.5, linear instead of squared
%   attention-proximity levels, and gamma in {0.8, 0.95, 0.99}.
%   For each variant the MDP is re-solved and
%     pctChanged   % of non-terminal states whose optimal action differs from nominal
%     stealthShare % of states where a stealth action is optimal
%     detourShare  % of states where a detour action is optimal
%   and the variant policy is evaluated by Monte Carlo in the NOMINAL
%   environment with the NOMINAL metrics (same seed for every variant), so
%   physical outcomes (intrusions, completion time) are directly comparable.
%   sweep: stealth share as the delay weight w_d is varied (range in which
%   stealth is selected).
if nargin < 3, nMC = 1000; end
if nargin < 4, seed = P.seed; end
V = {};  L = {};
wn = {'T','D','n','m','r','d'};
for k = 1:numel(wn)
    for f = [0.5 1.5]
        Pv = P;  Pv.w.(wn{k}) = f * P.w.(wn{k});
        V{end+1} = Pv;  L{end+1} = sprintf('w_%s x%.1f', wn{k}, f); %#ok<AGROW>
    end
end
Pv = P; Pv.disturbanceForm = 'linear'; V{end+1} = Pv; L{end+1} = 'linear levels (xa*xp)';
for g = [0.8 0.95 0.99]
    Pv = P; Pv.gamma = g; V{end+1} = Pv; L{end+1} = sprintf('gamma = %.2f', g); %#ok<AGROW>
end
V = [{P}, V];  L = [{'nominal'}, L];

act = 1:P.nActive;
isSt = ismember(modelNom.P.act.vel, 2);  isDt = modelNom.P.act.rho == 3;
cols = {'pctChanged','stealthShare','detourShare','return','returnCI','intrusions','severeIntrusions','completionTime','disturbance','actionSwitches'};
X = zeros(numel(V), numel(cols));
for k = 1:numel(V)
    if k == 1, mv = modelNom; else, mv = solve_mdp(V{k}); end
    pol = mv.policy(act);
    MC = run_monte_carlo({make_policy_mdp(mv, L{k})}, P, nMC, seed);
    X(k, :) = [100 * mean(pol ~= modelNom.policy(act)), 100 * mean(isSt(pol)), 100 * mean(isDt(pol)), ...
               MC.summary.returnDisc.mean, MC.summary.returnDisc.ci95, MC.summary.intrusions.mean, ...
               MC.summary.severeIntrusions.mean, MC.summary.completionTime.mean, ...
               MC.summary.disturbance.mean, MC.summary.actionSwitches.mean];
end
Tab.labels = L;  Tab.columns = cols;  Tab.data = X;

sweep.wd = 0:5:60;
sweep.stealthShare = zeros(size(sweep.wd));
sweep.detourShare  = zeros(size(sweep.wd));
for k = 1:numel(sweep.wd)
    Pv = P;  Pv.w.d = sweep.wd(k);
    mv = solve_mdp(Pv);  pol = mv.policy(act);
    sweep.stealthShare(k) = 100 * mean(isSt(pol));
    sweep.detourShare(k)  = 100 * mean(isDt(pol));
end
end
