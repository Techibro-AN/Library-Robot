function model = solve_mdp(P)
%SOLVE_MDP  Build the MDP from parameters P and solve it by value iteration.
%   model = solve_mdp(P) returns a struct with fields
%     P       finalized parameters
%     T       1-by-nA cell of sparse transition matrices (Eq. 3)
%     R       nS-by-nA expected rewards (Eq. 6)
%     V       optimal value function (Eq. 13), V(sT) = 0
%     Q       state-action values
%     policy  nS-by-1 optimal action index
%     info    solver diagnostics (iterations, residuals, runtime, tolerance)
if nargin < 1, P = params_default(); end
P = finalize_params(P);
model.P = P;
model.T = build_transition_model(P);
model.R = build_reward_model(model.T, P);
[model.V, model.policy, model.Q, model.info] = ...
    value_iteration(model.T, model.R, P.gamma, P.vi.epsilon, P.vi.maxIter);
end
