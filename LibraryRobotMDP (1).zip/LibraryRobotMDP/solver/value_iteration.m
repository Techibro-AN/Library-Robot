function [V, policy, Q, info] = value_iteration(T, R, gamma, epsilon, maxIter)
%VALUE_ITERATION  Synchronous value iteration for the Bellman equation (13).
%   V_0 = 0;  V_{k+1}(s) = max_a [ R(s,a) + gamma * sum_s' T{a}(s,s') V_k(s') ]
%   Stops when ||V_{k+1} - V_k||_inf < epsilon*(1-gamma)/(2*gamma), which
%   guarantees an epsilon-optimal greedy policy (Puterman, 1994, Thm 6.3.1).
%   For gamma = 0 the myopic solution Q = R is returned after one backup.
%
%   Ties in argmax are broken by the lowest action index (action order of
%   finalize_params), which makes the policy deterministic and reproducible.
nS = size(R, 1);  nA = size(R, 2);
V = zeros(nS, 1);
if gamma == 0
    tol = Inf;
else
    tol = epsilon * (1 - gamma) / (2 * gamma);
end
residual = zeros(maxIter, 1);
Q = zeros(nS, nA);
tStart = tic;
converged = false;
for k = 1:maxIter
    for a = 1:nA
        Q(:, a) = R(:, a) + gamma * (T{a} * V);
    end
    Vnew = max(Q, [], 2);
    residual(k) = max(abs(Vnew - V));
    V = Vnew;
    if residual(k) < tol || gamma == 0
        converged = true;
        break;
    end
end
for a = 1:nA                                   % greedy policy w.r.t. final V
    Q(:, a) = R(:, a) + gamma * (T{a} * V);
end
[~, policy] = max(Q, [], 2);
info.iterations = k;
info.residual   = residual(1:k);
info.tolerance  = tol;
info.converged  = converged;
info.runtime_s  = toc(tStart);
if ~converged
    warning('value_iteration:notConverged', 'Value iteration did not converge in %d iterations.', maxIter);
end
end
