function s = describe_script(v)
%DESCRIBE_SCRIPT  Text description of a scripted exogenous variable (scenario table).
if isempty(v) || all(isnan(v)), s = 'Markov chain';
elseif any(isnan(v)), s = 'partly scripted';
elseif all(v == v(1)), s = sprintf('fixed at %d', v(1));
else
    ch = [1, find(diff(v) ~= 0) + 1];
    s = strjoin(arrayfun(@(i) sprintf('%d from epoch %d', v(i), i), ch, 'UniformOutput', false), '; ');
end
end
