function E = env_info(P)
%ENV_INFO  Software environment and settings to report for reproducibility.
E.isOctave = exist('OCTAVE_VERSION', 'builtin') ~= 0;
if E.isOctave, E.platform = 'GNU Octave'; else, E.platform = 'MATLAB'; end
E.version  = version();
E.computer = computer();
E.date     = datestr(now, 'yyyy-mm-dd HH:MM:SS');
E.seed     = P.seed;
E.gamma    = P.gamma;
E.epsilon  = P.vi.epsilon;
end
