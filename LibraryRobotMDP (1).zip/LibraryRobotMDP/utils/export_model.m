function export_model(model, outDir)
%EXPORT_MODEL  Write the model and policy to CSV files (supplementary material).
%   policy.csv              state variables, optimal action, V*(s)
%   transitions_a<k>.csv    sparse triplets (from, to, probability) per action
%   rewards.csv             expected reward R(s,a)
%   actions.csv             action table (Table 2)
%   parameters.txt          all scalar/vector parameters
P = model.P;
if ~exist(outDir, 'dir'), mkdir(outDir); end
X = state_from_index((1:P.nS)', P);

fid = fopen(fullfile(outDir, 'policy.csv'), 'w');
fprintf(fid, 'state,xa,xm,xp,xc,xtd,action_index,action,V\n');
for i = 1:P.nS
    fprintf(fid, '%d,%g,%g,%g,%g,%g,%d,%s,%.10g\n', i, X(i,:), model.policy(i), ...
            P.act.name{model.policy(i)}, model.V(i));
end
fclose(fid);

for a = 1:P.nA
    [r, c, v] = find(model.T{a});
    fid = fopen(fullfile(outDir, sprintf('transitions_a%d.csv', a)), 'w');
    fprintf(fid, '# action %d: %s\nfrom,to,probability\n', a, P.act.name{a});
    fprintf(fid, '%d,%d,%.12g\n', [r c v]');
    fclose(fid);
end

fid = fopen(fullfile(outDir, 'rewards.csv'), 'w');
fprintf(fid, 'state%s\n', sprintf(',%s', P.act.name{:}));
fprintf(fid, ['%d' repmat(',%.10g', 1, P.nA) '\n'], [(1:P.nS)' model.R]');
fclose(fid);

fid = fopen(fullfile(outDir, 'actions.csv'), 'w');
fprintf(fid, 'index,name,speed_mps,extra_path,segment_prob,noise_level\n');
for a = 1:P.nA
    fprintf(fid, '%d,%s,%g,%g,%.4f,%g\n', a, P.act.name{a}, P.act.speed(a), ...
            P.act.dl(a), P.act.p(a), P.act.nl(a));
end
fclose(fid);

fid = fopen(fullfile(outDir, 'parameters.txt'), 'w');
write_struct(fid, rmfield(P, {'act'}), '');
fprintf(fid, 'solver.iterations = %d\nsolver.tolerance = %.3g\nsolver.runtime_s = %.3f\n', ...
        model.info.iterations, model.info.tolerance, model.info.runtime_s);
fclose(fid);
end

function write_struct(fid, S, prefix)
f = fieldnames(S);
for k = 1:numel(f)
    v = S.(f{k});  name = [prefix f{k}];
    if isstruct(v)
        write_struct(fid, v, [name '.']);
    elseif ischar(v)
        fprintf(fid, '%s = %s\n', name, v);
    elseif isnumeric(v) || islogical(v)
        fprintf(fid, '%s = %s\n', name, mat2str(double(v), 6));
    end
end
end
