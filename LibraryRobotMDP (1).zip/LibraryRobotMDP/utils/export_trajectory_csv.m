function export_trajectory_csv(logs, idx, P, prefix)
%EXPORT_TRAJECTORY_CSV  Write trajectories for the paper figures.
%   One CSV per policy: <prefix>_p<k>.csv with columns
%   [epoch, xa, xp, velocity index, routing index].
for k = idx
    L = logs{k};
    M = [(1:L.nSteps)', L.xa, L.xp, P.act.vel(L.a)', P.act.rho(L.a)'];
    dlmwrite(sprintf('%s_p%d.csv', prefix, k), M);
end
end
