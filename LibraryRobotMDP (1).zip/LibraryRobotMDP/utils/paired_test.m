function T = paired_test(x, y)
%PAIRED_TEST  Paired t-test on per-episode values (common random numbers).
%   T = paired_test(x, y) compares x (e.g. MDP) with y (a baseline) episode
%   by episode. Returns mean difference d = mean(x - y), its 95% CI, the
%   t statistic, the two-sided p-value and the effect size dz = mean/std.
%   Uses only base functions (betainc), so no toolbox is required.
d = x(:) - y(:);
d = d(~isnan(d));
n = numel(d);
T.n = n;
T.meanDiff = mean(d);
sd = std(d);
T.ci95 = [T.meanDiff - 1.96 * sd / sqrt(n), T.meanDiff + 1.96 * sd / sqrt(n)];
if sd == 0
    T.t = Inf * sign(T.meanDiff);  T.p = double(T.meanDiff == 0);  T.dz = Inf;
    if T.meanDiff == 0, T.t = 0; T.dz = 0; end
    return;
end
T.t  = T.meanDiff / (sd / sqrt(n));
df   = n - 1;
T.p  = betainc(df / (df + T.t^2), df / 2, 0.5);    % two-sided p-value
T.dz = T.meanDiff / sd;
end
