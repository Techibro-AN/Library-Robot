function fig = plot_policy_summary(S, outFile)
%PLOT_POLICY_SUMMARY  Stacked bars of optimal-action shares by attention and by proximity.
used = find(sum([S.byAttention; S.byProximity], 1) > 0);
vis = 'on';
if exist('OCTAVE_VERSION', 'builtin') && isempty(getenv('DISPLAY')), vis = 'off'; end
fig = figure('Color', 'w', 'Position', [100 100 900 420], 'Visible', vis);
subplot(1, 2, 1);
bar(0:2, S.byAttention(:, used), 'stacked');
set(gca, 'XTick', 0:2, 'XTickLabel', {'distracted','moderate','deep'}, 'FontSize', 11);
xlabel('Attention x_a'); ylabel('Share of states (%)'); ylim([0 100]); box on;
subplot(1, 2, 2);
bar(0:2, S.byProximity(:, used), 'stacked');
set(gca, 'XTick', 0:2, 'XTickLabel', {'far','near','intimate'}, 'FontSize', 11);
xlabel('Proximity x_p'); ylim([0 100]); box on;
legend(S.actionNames(used), 'Location', 'eastoutside');
if nargin > 1 && ~isempty(outFile), print(fig, outFile, '-dpng', '-r300'); end
end
