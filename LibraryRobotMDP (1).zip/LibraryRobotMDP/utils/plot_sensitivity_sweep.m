function fig = plot_sensitivity_sweep(sweep, wdNominal, outFile)
%PLOT_SENSITIVITY_SWEEP  Share of states choosing stealth / detour versus delay weight w_d.
vis = 'on';
if exist('OCTAVE_VERSION', 'builtin') && isempty(getenv('DISPLAY')), vis = 'off'; end
fig = figure('Color', 'w', 'Position', [100 100 700 420], 'Visible', vis);
plot(sweep.wd, sweep.stealthShare, '-o', 'LineWidth', 1.6); hold on;
plot(sweep.wd, sweep.detourShare, '--s', 'LineWidth', 1.6);
yl = [0 100];  plot([wdNominal wdNominal], yl, 'k:', 'LineWidth', 1.2);
ylim(yl); box on; set(gca, 'FontSize', 11);
xlabel('Delay weight w_d'); ylabel('Share of states (%)');
legend({'stealth velocity optimal', 'detour optimal', 'nominal w_d'}, 'Location', 'northeast');
if nargin > 2 && ~isempty(outFile), print(fig, outFile, '-dpng', '-r300'); end
end
