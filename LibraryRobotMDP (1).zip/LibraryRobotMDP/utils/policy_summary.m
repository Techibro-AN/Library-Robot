function S = policy_summary(model)
%POLICY_SUMMARY  Distribution of optimal actions across the non-terminal states.
%   S.overall(a)        share of states where action a is optimal
%   S.byAttention(k,a)  share within states with xa = k-1
%   S.byProximity(k,a)  share within states with xp = k-1
%   S.byCrowd(k,a)      share within states with xc = k-1
%   S.byMobility(k,a)   share within states with xm = k-1
%   All values in percent; columns follow model.P.act.name.
P = model.P;
X = state_from_index((1:P.nActive)', P);
a = model.policy(1:P.nActive);
cnt = @(mask) 100 * accumarray(a(mask), 1, [P.nA 1])' / sum(mask);
S.actionNames = P.act.name;
S.overall = cnt(true(P.nActive, 1));
for k = 0:2
    S.byAttention(k+1, :) = cnt(X(:,1) == k);
    S.byProximity(k+1, :) = cnt(X(:,3) == k);
    S.byCrowd(k+1, :)     = cnt(X(:,4) == k);
end
for k = 0:1
    S.byMobility(k+1, :) = cnt(X(:,2) == k);
end
end
