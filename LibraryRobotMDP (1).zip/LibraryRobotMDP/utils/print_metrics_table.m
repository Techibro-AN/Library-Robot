function print_metrics_table(names, M, ci)
%PRINT_METRICS_TABLE  Print a policy-by-metric table to the command window.
%   names  cell array of policy names
%   M      struct array (one per policy, from compute_metrics) or MC.summary
%   ci     true when M is MC.summary (prints mean +/- 95% CI)
if nargin < 3, ci = false; end
cols = {'returnDisc','tasksCompleted','completionTime','intrusions','severeIntrusions', ...
        'disturbance','noiseExposure','actionSwitches','proxReversals','meanSpeed'};
hdr  = {'Return','Tasks','T_done','Intr','SevIntr','Disturb','Noise','Switch','Revers','Speed'};
fprintf('%-24s', 'Policy'); fprintf('%16s', hdr{:}); fprintf('\n');
for k = 1:numel(names)
    fprintf('%-24s', names{k});
    for j = 1:numel(cols)
        if ci
            fprintf('%16s', sprintf('%.2f+-%.2f', M.(cols{j}).mean(k), M.(cols{j}).ci95(k)));
        else
            fprintf('%16.2f', M(k).(cols{j}));
        end
    end
    fprintf('\n');
end
end
