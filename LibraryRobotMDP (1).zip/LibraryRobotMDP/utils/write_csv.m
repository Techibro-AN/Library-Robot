function write_csv(file, header, rowLabels, X)
%WRITE_CSV  Write a table with text row labels and a numeric matrix.
%   header     cell array of column names (first entry names the label column)
%   rowLabels  cell array (one per row) or [] for none
%   X          numeric matrix (rows x columns)
fid = fopen(file, 'w');
fprintf(fid, '%s', header{1});
fprintf(fid, ',%s', header{2:end});
fprintf(fid, '\n');
for i = 1:size(X, 1)
    if ~isempty(rowLabels), fprintf(fid, '"%s",', rowLabels{i}); end
    fprintf(fid, '%.6g', X(i, 1));
    fprintf(fid, ',%.6g', X(i, 2:end));
    fprintf(fid, '\n');
end
fclose(fid);
end
